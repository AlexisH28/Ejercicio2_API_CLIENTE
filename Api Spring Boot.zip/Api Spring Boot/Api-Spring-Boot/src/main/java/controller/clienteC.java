package controller;

import entidad.Cliente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ui.Model;

import java.util.ArrayList;

@RestController
public class clienteC {
    @GetMapping("/api/clientes")
    public String cliente(Model model){

        ArrayList clientes = new ArrayList<>();

        clientes.add(new Cliente("Juan",22));
        clientes.add(new Cliente("Maria",25));
        clientes.add(new Cliente("Pedro",28));
        clientes.add(new Cliente("Luis",32));

        return clientes.toString();
    }
}
