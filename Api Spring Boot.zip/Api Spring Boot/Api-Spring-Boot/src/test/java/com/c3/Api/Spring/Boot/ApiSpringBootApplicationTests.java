package com.c3.Api.Spring.Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
